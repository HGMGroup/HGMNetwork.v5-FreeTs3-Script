<?php

return (object) array(

  'appInfo' => (object) array(

    'pageTitle' => 'Baslik',

    'pageHeader' => 'Ts3 Server Olusturma Scripti',

    'pageSubHeader' => 'Hosted/Scripted By HGMNetwork'

  ),

  'appSettings' => (object) array(


  ),

  'teamspeakInfo' => (object) array(





  )

);

?>

