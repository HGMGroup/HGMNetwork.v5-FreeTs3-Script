<?php

require_once("libraries/TeamSpeak3/TeamSpeak3.php");

$cfg = include('config.php');

define('6755682621', TRUE);



function getContent(){

  if(isset($_GET['page'])){

    switch ($_GET['page']) {

      case 'home':

        include('inc/home.php');

        break;



      case 'serverlist':

        include('inc/serverlist.php');

        break;



      case 'createServer':

          include('inc/createServer.php');

          break;



      default:

        include('inc/404.php');

        break;

    }

  }else{

    include('inc/home.php');

  }

}

?>



<html>

  <head>

    <title><?php echo $cfg->appInfo->pageTitle; ?> > TeamSpeak 3 Olusturma Sistemi</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="https://use.fontawesome.com/113608e34e.js"></script>

  </head>

  <body>

   <body background="bg_page.png">

    <div class="jumbotron text-center">

      <h1><?php echo $cfg->appInfo->pageHeader; ?></h1>

      <p><?php echo $cfg->appInfo->pageSubHeader; ?></p>

    </div>



    <div class="container">

      <div class="row">

        <div class="col-sm-3">

          <div class="panel panel-default">

            <div class="panel-heading">Secenekler</div>

            <div class="list-group">

              <a class="list-group-item" href="?page=home"><i class="fa fa-home fa-fw" aria-hidden="true"></i>&nbsp; Ana Sayfa</a>

              <a class="list-group-item" href="?page=serverlist"><i class="fa fa-server fa-fw" aria-hidden="true"></i>&nbsp; Server Listesi</a>

              <a class="list-group-item" href="?page=createServer"><i class="fa fa-plus-circle fa-fw" aria-hidden="true"></i>&nbsp; Sunucu Oluştur</a>

              <a class="list-group-item" target="_blank" href="#"><i class="fa fa-diamond" aria-hidden="true"></i>&nbsp; Forum</a>


            </div>

          </div>

        </div>

        <div class="col-sm-9">

          <?php getContent(); ?>

        </div>

      </div>

    </div>

  </body>

</html>

