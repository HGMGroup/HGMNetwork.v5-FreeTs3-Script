<?php

if(!defined('6755682621')) {

   die('Direct access not permitted');

}

?>

<div class="panel panel-default">

  <div class="panel-heading">Ana Sayfa</div>

  <div class="panel-body">

    <p>Bu Alana Siteniz Veya Klaniniz Hakkinda Bilgiler,Gelismeler,Durumlar Paylasabilir,Ekleyebilir Veya Duzenleyebilirsiniz...</p>

  </div>

</div>

