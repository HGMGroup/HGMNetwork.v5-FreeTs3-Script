<?php

if(!defined('6755682621')) {

   die('Direct access not permitted');

}

?>

<div class="panel panel-default">

  <div class="panel-heading">404 Error - Sayfa Bulunamadi</div>

  <div class="panel-body">

    <center>

      <h3>Aramaya Calistiniz Sayfa Bulunamadi.</h3>

      <h4>¯\_(ツ)_/¯</h4>

    </center>

  </div>

</div>

